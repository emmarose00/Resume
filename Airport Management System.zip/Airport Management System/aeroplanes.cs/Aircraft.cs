﻿using System;
using System.Collections.Generic;


namespace aeroplanes.cs
{
    class Aircraft
    {
        //varibales required from employee
        public string DeparturePlace;
        public string ArrivalPlace;
        public string DepartureTime;
        public float Distrance;

        public int TypeAircraft; //(3)Helicopter or (2)Light Aircraft

        public List<string> CustomersOnAircraft;

        //constants
        public int MaxSeats;
        public float Cost;
        public float Speed;

        public Aircraft(int typeAircraft,string departurePlace, string arrivalPlace, string departureTime, float distrance)
        {
            this.TypeAircraft = typeAircraft;

            this.DeparturePlace = departurePlace;
            this.ArrivalPlace = arrivalPlace;
            this.DepartureTime = departureTime;
            this.Distrance = distrance;

            if (typeAircraft == 2) //is a light aircraft
            {
                this.MaxSeats = 6;
                this.Cost = 250/60;    //$250 per 800km
                this.Speed = 800/60;   //600km/h or 
            }
            else if (typeAircraft == 3) //is a helicopter
            {
                this.MaxSeats = 2;
                this.Cost = 600/60;    //$600 per 120km
                this.Speed = 120/60;  //120Km/h or 2km/min
            }

            this.CustomersOnAircraft = new List<string>();

        }

        public Aircraft()
        {
        }

        public Aircraft RegisterNewAircraft(int typeAircraft)
        {
            Console.Write("Departurn Place: ");
            string departurePlace = Console.ReadLine();

            Console.Write("Arrival Place: ");
            string arrivalPlace = Console.ReadLine();

            Console.Write("Departure Time (hh:mm): ");
            string departureTime = Console.ReadLine();

            Console.Write("Distance (km): ");
            float distance = float.Parse(Console.ReadLine());

            Aircraft newAircraft = new Aircraft(typeAircraft, departurePlace, arrivalPlace, departureTime, distance);
            
            if (typeAircraft == 2) //light aircraft
            {
                Console.WriteLine("Light Aircarft " + departurePlace + " to " + arrivalPlace + " added\n");
            }
            else if (typeAircraft == 3) //helicopter
            {
                Console.WriteLine("Helicopter from " + departurePlace + " to " + arrivalPlace + " added\n");
            }
            
            return new Aircraft(typeAircraft, departurePlace, arrivalPlace, departureTime, distance);
        }
    }
}
