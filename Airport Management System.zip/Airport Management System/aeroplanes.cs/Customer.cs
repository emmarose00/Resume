﻿using System;


namespace aeroplanes.cs
{
    public class Customer
    {
        public string Name;
        public string Email;
        public string Address;
        public int Mobile;

        public Customer(string name, string email, string address, int mobile)
        {
            this.Name = name;
            this.Email = email;
            this.Address = address;
            this.Mobile = mobile;
        }

        public Customer()
        {
        }

        public Customer RegisterCustomer()
        {
            Console.Write("Full Name: ");
            string name = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            Console.Write("Mobile: ");
            int mobile = Int32.Parse(Console.ReadLine());

            Customer newCustomer = new Customer(name, email, address, mobile);
            
            Console.WriteLine(newCustomer.Name + " registered successfully\n");

            return new Customer(name,email,address,mobile);

        }

    }
}
