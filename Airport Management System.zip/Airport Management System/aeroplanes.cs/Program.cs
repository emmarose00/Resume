﻿using System;
using System.Collections.Generic;
// run without debugging cntr + F5  :)

namespace aeroplanes.cs
{
    class Program
    {
        private List<Customer> customerList;
        private List<Aircraft> aircraftList;
        private List<Employee> employeeList;

        void ExistingFlyingServices()
        {
            for (int i = 0; i < aircraftList.Count; i++)
            {
                if (aircraftList[i].TypeAircraft == 2)
                {
                    Console.WriteLine("Light Aircarft " +aircraftList[i].DeparturePlace+ " " +aircraftList[i].ArrivalPlace+ " " +aircraftList[i].Distrance);
                }
                else if (aircraftList[i].TypeAircraft == 3)
                {
                    Console.WriteLine("Helicopter " +aircraftList[i].DeparturePlace+ " " +aircraftList[i].ArrivalPlace+ " " +aircraftList[i].Distrance);
                }
            }
            Console.WriteLine();
        }

        void ExisitingTimes()
        {

            for (int i = 0; i < aircraftList.Count; i++)
            {
                if (aircraftList[i].TypeAircraft == 2)
                {
                    Console.WriteLine("Light Aircarft " + aircraftList[i].DeparturePlace + " " + aircraftList[i].ArrivalPlace + " " + aircraftList[i].DepartureTime + " " + Math.Floor(aircraftList[i].Distrance/aircraftList[i].Speed) + " minutes");
                }
                else if (aircraftList[i].TypeAircraft == 3)
                {
                    Console.WriteLine("Helicopter " + aircraftList[i].DeparturePlace + " " + aircraftList[i].ArrivalPlace + " " + aircraftList[i].DepartureTime + " " + Math.Floor(aircraftList[i].Distrance/aircraftList[i].Speed) + " minutes");
                }
            }
            Console.WriteLine();
        }

        void AddCustomerToFlight()
        {
            for (int i = 0; i < customerList.Count; i++)
            {
                Console.WriteLine(i+1 + " " + customerList[i].Name);
            }

            Console.Write("Get the customer number: ");
            int optionCustomer = Int32.Parse(Console.ReadLine());
            
            if(optionCustomer > 0 && optionCustomer <= customerList.Count)
            {
                for (int i = 0; i < aircraftList.Count; i++)
                {
                    Console.WriteLine(i + 1 + " " + aircraftList[i].DeparturePlace + " " + aircraftList[i].ArrivalPlace);
                }

                Console.Write("Get the flight number: ");
                int optionFlight = Int32.Parse(Console.ReadLine());

                if (optionFlight > 0 && optionFlight <= aircraftList.Count)
                {
                    if (aircraftList[optionFlight - 1].CustomersOnAircraft.Count < aircraftList[optionFlight - 1].MaxSeats)
                    {
                        aircraftList[optionFlight - 1].CustomersOnAircraft.Add(customerList[optionCustomer - 1].Name);
                    }
                    else
                    {
                        Console.WriteLine("aircraft at max capacity\n");
                    }


                    Console.WriteLine("Customer " + customerList[optionCustomer - 1].Name + " added.");
                    Console.WriteLine("Cost is $" + aircraftList[optionFlight - 1].Cost * aircraftList[optionFlight - 1].Distrance);
                    Console.WriteLine();
                }
                else {
                    Console.WriteLine("Invalid option\n");
                }
            }
            else
            {
                Console.WriteLine("Invalid option\n");
            }

        }

        void ViewFlight()
        {
            for (int i = 0; i < aircraftList.Count; i++)
            {
                Console.WriteLine(i + 1 + " " + aircraftList[i].DeparturePlace + " " + aircraftList[i].ArrivalPlace);
            }

            Console.Write("Get the flight number: ");
            int optionFlight = Int32.Parse(Console.ReadLine());

            if (optionFlight > 0 && optionFlight <= customerList.Count)
            {
                if (aircraftList[optionFlight - 1].CustomersOnAircraft.Count == aircraftList[optionFlight - 1].MaxSeats)
                {
                    Console.WriteLine("Flying machine is full\n");
                }
                else
                {
                    for (int i = 0; i < aircraftList[optionFlight - 1].CustomersOnAircraft.Count; i++)
                    {
                        Console.WriteLine(aircraftList[optionFlight - 1].CustomersOnAircraft[i]);
                    }
                    Console.WriteLine("No customers");
                    Console.WriteLine("Current Capacity: " + aircraftList[optionFlight - 1].CustomersOnAircraft.Count + "/" + aircraftList[optionFlight - 1].MaxSeats + "\n");
                }
            }
            else
            {
                Console.WriteLine("Invalid option\n");
            }

        }

        bool LoginEmployee(Employee newEmployee)
        {

            bool loggingIn = true;
            while (loggingIn)
            {
                Console.Write("Email: ");
                string loginEmail = Console.ReadLine();
                if (!String.IsNullOrEmpty(loginEmail))
                {
                    Console.Write("Password: ");
                    string loginPassword = newEmployee.HidePassword();

                    for (int i = 0; i < employeeList.Count; i++)
                    {

                        if (loginEmail == employeeList[i].Email && loginPassword == employeeList[i].Password)
                        {
                            Console.WriteLine("Welcome " + employeeList[i].Name + "\n");
                            return true;
                        }
                        else
                        {
                            Console.WriteLine("Invalid email or password, please try again");
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        void MainMenu()
        {
            bool running = true;
            customerList = new List<Customer>();
            aircraftList = new List<Aircraft>();

            Customer newCustomer = new Customer();
            Aircraft newAircraft = new Aircraft();

            while (running)
            {
                Console.WriteLine("Please select one of the following");
                Console.WriteLine("1) Register a Customer");
                Console.WriteLine("2) Register a new light aircraft");
                Console.WriteLine("3) Register a new helicopter");
                Console.WriteLine("4) View existing flying services");
                Console.WriteLine("5) View existing times");
                Console.WriteLine("6) Add a customer to a flying service");
                Console.WriteLine("7) View flight passengers");
                Console.WriteLine("8) Logout\n");

                int option = Int32.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        customerList.Add(newCustomer.RegisterCustomer());
                        break;
                    case 2: case 3:
                        aircraftList.Add(newAircraft.RegisterNewAircraft(option));
                        break;
                    case 4:
                        ExistingFlyingServices();
                        break;
                    case 5:
                        ExisitingTimes();
                        break;
                    case 6:
                        AddCustomerToFlight();
                        break;
                    case 7:
                        ViewFlight();
                        break;
                    case 8:
                        running = false;
                        Console.WriteLine("logging out");
                        break;
                }
            }
        }

        void LoginMenu()
        {
            bool running = true;
            employeeList = new List<Employee>();
            
            while (running)
            {
                Console.WriteLine("Please select one of the following");
                Console.WriteLine("1) Register as new Employee");
                Console.WriteLine("2) Login as existing Employee");
                Console.WriteLine("3) Exit\n");

                int option = Int32.Parse(Console.ReadLine());
                Employee newEmployee = new Employee();
            
                switch (option)
                {
                    case 1:
                        employeeList.Add(newEmployee.RegisterEmployee());
                        break;
                    case 2:
                        if (LoginEmployee(newEmployee))
                        {
                            MainMenu();
                        }
                        break;
                    case 3:
                        running = false;
                        break;
                }
            }
        }

        static void Main(string[] args)
        {
            Program program = new Program();
            program.LoginMenu();
        }
    }
}
