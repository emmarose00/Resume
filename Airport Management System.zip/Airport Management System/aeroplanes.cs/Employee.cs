﻿using System;


namespace aeroplanes.cs
{
    class Employee
    {
        public string Name;
        public string Email;
        public string Password;
        


        public Employee(string name, string email, string password)
        {
            this.Name = name;
            this.Email = email;
            this.Password = password;
        }

        public Employee(){
        }

        public string HidePassword()
        {
            var password = new System.Text.StringBuilder();
            while (true)
            {
                var keyInfo = Console.ReadKey(intercept: true);
                var key = keyInfo.Key;

                if (key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        Console.Write("\b \b");
                        password.Remove(password.Length - 1, 1);
                    }
                }
                else
                {
                    Console.Write("*");
                    password.Append(keyInfo.KeyChar);
                }
            }

            Console.WriteLine();
            return password.ToString();
        }

        public Employee RegisterEmployee()
        {

            Console.Write("Full Name: ");
            string name = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            Console.Write("Password: ");
            string passwordFull = HidePassword();

            Employee newEmployee = new(name, email, passwordFull);
        
            Console.WriteLine(newEmployee.Name + " registered successfully\n");

            return new Employee(name, email, passwordFull);
        }

    }

}

