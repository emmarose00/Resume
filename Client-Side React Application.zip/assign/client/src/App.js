import React, { useState } from "react";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Header from "./components/Header";
import Footer from "./components/Footer";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Home from "./pages/Home";
import VolcanoList from "./pages/VolcanoList";
import Volcano from "./pages/Volcano";

export default function App() {
  let [token, setToken] = useState(localStorage.getItem('token'));

  return (
    <BrowserRouter>
      <div className="App">
        <Header token={token} setToken={setToken} />
        {/* pass it into header that goes into nav */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/volcanoList" element={<VolcanoList />} />
          <Route path="/login" element={<Login setToken={setToken} />} />
          <Route path="/register" element={<Register />} />
          <Route path="/volcano" element={<Volcano token={token} />} />
        </Routes>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
