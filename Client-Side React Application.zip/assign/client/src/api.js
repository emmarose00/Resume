import { useEffect, useState } from 'react';

function getCountries() {
    return fetch(
        `http://sefdb02.qut.edu.au:3001/countries`
    )
        .then((res) => res.json())
        .then((res) => {
            if ("error" in res) {
                throw new Error(res.error.message);
            }
            return res;
        })
}

export function useCountries(query) {
    const [loading, setLoading] = useState(true);
    const [countries, setCountries] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        getCountries(query)
            .then((countries) => {
                setCountries(countries);
                setLoading(false);
                setError(null);
            })
            .catch((err) => setError(err.message));
    }, [query]);

    return {
        loading: loading,
        countries: countries,
        error: error
    };
}