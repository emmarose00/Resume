import React from "react";
import { Link } from "react-router-dom";

// navigation links
export default function Nav({ token, setToken }) {

  function LoggedIn() {
    if (token) {
      return (
        <div>
          <li>
            <Link to="/" onClick={() => { localStorage.removeItem('token'); setToken(null) }}>Log Out</Link>
          </li>
        </div>
      );
    }
    return (
      <div>
        <li>
          <Link to="/login" token={token}>Login</Link>
        </li>
        <li>
          <Link to="/register">Register</Link>
        </li>
      </div>
    );
  }

  return (
    <nav>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/volcanoList" token={token} >Volcano List</Link>
          {/* menu */}
        </li>
        <LoggedIn></LoggedIn>
      </ul>
    </nav>
  );
}
