import React from "react";

// the footer
export default function Footer() {
  return (
    <footer>
      <span>
        Volcanoes
      </span>
    </footer>
  );
}
