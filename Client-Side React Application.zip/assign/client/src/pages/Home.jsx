import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <main>
      <Hero />
    </main>
  );
}

const Hero = () => (
  <section className="hero">
    {/* content for the hero */}
    <div className="hero__content">
      <div>
        <h1 className="hero__title">Volcanoes</h1>
        <p className="hero__subtitle">discover the volcanoes around world</p>
      </div>

      <div className="divButtons">
        <Link to="/volcanoList">Volcano List</Link>
        <Link to="/login">Login</Link>
      </div>


    </div>
  </section>
);
