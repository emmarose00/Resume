import { useNavigate, useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";

import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

import { Map, Marker } from "pigeon-maps"
import "../App.css";
import { Bar } from "react-chartjs-2";


function BarGraph({ token, volcano }) {
    if (token) {
        const options = {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Populated Density',
                },
            },
        };

        const labels = ['10km', '30km', '50km', '100km'];

        const data = {
            labels,
            datasets: [
                {
                    label: "population",
                    data: [volcano.population_5km, volcano.population_10km, volcano.population_30km, volcano.population_100km],
                    //data: ["5100", "3500", "5300", "900"],
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                },
            ],
        };

        return (
            <div>
                <p>Bar Graph</p>
                <Bar options={options} data={data} />
            </div>
        );
    }
    return (
        <p>Log in to see more data</p>
    );
}


export default function Volcano({ token }) {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const id = searchParams.get("id");
    const [volcano, setvolcano] = useState({});

    useEffect(() => {
        let url = "http://sefdb02.qut.edu.au:3001/volcano/" + id;
        let headers = {
            'Content-Type': 'application/json'
        }
        if (token) {
            headers = {
                ...headers,
                'Authorization': `Bearer ${token}`
            }
        }

        fetch(url, {
            headers,
        })
            .then((res) => res.json())
            .then((data) => setvolcano(data))
    }, [])



    function MyMap() {

        return (
            <Map height={300} defaultCenter={[+volcano.latitude, +volcano.longitude]} defaultZoom={11}>
                <Marker width={50} anchor={[+volcano.latitude, +volcano.longitude]} />
            </Map>
        )

    }

    return (
        <div className="container">
            <div className="infomation">
                <h1>{volcano.name}</h1>
                <p>Country: {volcano.country}</p>
                <p>Region: {volcano.region}</p>
                <p>Subregion: {volcano.subregion}</p>
                <p>Last Eruption: {volcano.last_eruption}</p>
                <p>Summit: {volcano.summit} m</p>
                <p>Elevation: {volcano.elevation} ft</p>
            </div>
            <br />
            <br />

            <div className="maps">
                {volcano.latitude ? <MyMap></MyMap> : null}
            </div>
            <br />
            <br />
            <BarGraph token={token} volcano={volcano} />
        </div>
    );
}

