import React, { useState } from "react";

export default function Register() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  function register() {
    const url = `http://sefdb02.qut.edu.au:3001/user/register`
    return (
      fetch(url, {
        method: "POST",
        headers: { accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, password: password })
      })
        .then(res => res.json())
        .then(res => {
          localStorage.setItem("token", res.token);
        })
    );
  }
  return (
    <main>
      <div className="container">
        <h2>Register</h2>
        <section>
          <div>
            <label for="email">Email: </label>
            <input type="text" id="email" name="email" placeholder="example@gmail.com" value={email} onChange={(event) => setEmail(event.target.value)}></input>
            &emsp;
            <label for="pwd">Password: </label>
            <input type="password" id="pwd" name="pwd" placeholder="********" value={password} onChange={(event) => setPassword(event.target.value)}></input>
            <br />
            <br />
          </div>
        </section>
        <button onClick={() => register}>Create</button>
        <br />
        <br />
      </div>
    </main>
  )
}

