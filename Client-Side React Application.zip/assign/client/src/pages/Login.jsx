import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css";


export default function Login(props) {
  const navigate = useNavigate();
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  const { token, setToken } = props;

  const login = () => {
    const url = `http://sefdb02.qut.edu.au:3001/user/login`

    return (
      fetch(url, {
        method: "POST",
        headers: { accept: "application/json", "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, password: password })
      })
        .then(res => res.json())
        .then(res => {
          localStorage.setItem("token", res.token);
          setToken(res.token)
          navigate(`/`)
        })
    );
  }

  return (

    <main>
      <div className="container">
        <h2>Login</h2>
        <div>
          <section>
            <div>
              <form >
                <label for="email">Email: </label>
                <input type="text" id="email" name="email" placeholder="example@gmail.com" value={email} onChange={(event) => setEmail(event.target.value)}></input>
                &emsp;
                <label for="pwd">Password: </label>
                <input type="password" id="pwd" name="pwd" placeholder="********" value={password} onChange={(event) => setPassword(event.target.value)}></input>
                <br />
                <br />
              </form>
            </div>
          </section>
          <button onClick={() => login()}>Login</button>
        </div>
        <br />
        <br />
      </div>

    </main>

  );
}
