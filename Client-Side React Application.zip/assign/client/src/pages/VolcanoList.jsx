import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import DropDownBox from "../DropDownBox";
import { useCountries } from "../api";

//code for table
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-balham.css";


export default function VolcanoList({ token }) {
  var [populatedWithin, setPopulatedWithin] = useState();
  const [populatedWithinOptions, setPopulatedWithinOptions] = useState(['5km', '10km', '30km', '100km']);
  const { countries } = useCountries();
  const [country, setCountry] = useState();
  const [rowData, setRowData] = useState([])

  //table code
  const navigate = useNavigate();
  const columns = [
    { headerName: "Name", field: "name", sortable: true, filter: true },
    { headerName: "Region", field: "region" },
    { headerName: "Subregion", field: "subregion" }
  ];

  function handleClick() {
    let url = "http://sefdb02.qut.edu.au:3001/volcanoes?country=" + country;

    if (populatedWithin) {
      url += "&populatedWithin=" + populatedWithin
    }
    fetch(url)
      .then((res) => res.json())
      .then((data) => setRowData(data))
  }

  return (
    <div>
      < p > Country: {country}</p >
      <DropDownBox
        options={countries}
        label="Countries"
        onChange={setCountry}
      />

      <p>Populated Within: {populatedWithin}</p>
      <DropDownBox
        options={populatedWithinOptions}
        label="Populated Within"
        onChange={setPopulatedWithin}
      />
      <button onClick={() => handleClick()}>Search</button>
      <br />
      <br />

      <div>
        <div
          className="ag-theme-balham"
          style={{
            height: "300px",
            width: "800px"
          }}
        >
          <AgGridReact
            columnDefs={columns}
            rowData={rowData}
            pagination
            paginationPageSize={7}
            onRowClicked={(row) => navigate(`/volcano?id=${row.data.id}`)}
          />
        </div>
      </div>
    </div >
  );
}
