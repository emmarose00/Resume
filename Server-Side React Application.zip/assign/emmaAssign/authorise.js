const jwt = require('jsonwebtoken')

const authorize = (req, res, next, softFall = false) => {
    const authorization = req.headers.authorization
    let token = null;

    if (authorization && authorization.split(" ").length === 2) {
        token = authorization.split(" ")[1]
        //authorized

        //verify JWT and check expiration date
        try {
            const decoded = jwt.verify(token, process.env.SECRET_KEY)
            if (decoded.exp < Date.now()) {
                //token expired, return error message
                res.status(401).json({
                    "error": true,
                    "message": "Invalid JWT token"
                })
                return;
            }
            //allow user to advance
            res.locals.isAuthed = true;
            res.locals.email = decoded.email;
            next()
        } catch (e) {
            console.log(e)
            //token not valid, return error messgae
            res.status(401).json({
                "error": true,
                "message": "Invalid JWT token"
            })
        }
    } else if (!authorization && softFall) {
        // unauthorized, allow the public data
        res.locals.isAuthed = false;
        res.locals.email = null;
        next()
    } else {
        //token is malformed
        res.status(401).json({
            "error": true,
            "message": 'Authorization header is malformed'
        })
    }
}

module.exports = authorize;
