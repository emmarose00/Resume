var express = require('express');
var router = express.Router();

router.get('/', function (req, res, next) {

    //decontruct query
    const { country, populatedWithin, ...remaining } = req.query;

    //Test for no country
    if (country == null) {
        res.status(400).json({ "error": true, "message": "Country is a required query parameter." });
        return;
    }

    //Test for invalid populatedWithin values
    if (!populatedWithin === "5km" && !populatedWithin === "10km" && !populatedWithin === "30km" && !populatedWithin === "100km" && !populatedWithin == null) {
        res.status(400).json({ "error": true, "message": "Invalid value for populatedWithin. Only: 5km,10km,30km,100km are permitted." });
        return;
    }

    //Test for invalid parameters
    if (Object.keys(remaining).length > 0) {
        res.status(400).json({ "error": true, "message": "Invalid query parameters. Only country and populatedWithin are permitted." });
        return;
    }

    const query = req.db.from('data').where('country', country)

    //test for invalid populatedWithin
    if (populatedWithin) {
        query.where(`population_${populatedWithin}`, '>', 0)
    }

    //get data from database
    query.select('id', 'name', 'country', 'region', 'subregion')
        .then(rows => {
            res.status(200).json(rows);
            return;
        })
        .catch(err => {
            console.log(err);
            //error if failed to fetch data
            res.status(200).json({ "error": true, "message": "Error in MySQL query" });
            return;
        }
        )
});

module.exports = router;
