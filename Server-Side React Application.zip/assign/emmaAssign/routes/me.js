var express = require('express');
var router = express.Router();

router.get('/', function (req, res, next) {
    res.json({ "name": "Emma Rose", "student_number": "n10700137" }
    );
});

module.exports = router;
