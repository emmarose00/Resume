var express = require('express');
var router = express.Router();

const authorize = require('../authorise');

router.get('/:id', (req, res, next) => authorize(req, res, next, true), (req, res, next) => {

    //desired parameters required depending on if authorised or not
    const authedCols = ['population_5km', 'population_10km', 'population_30km', 'population_100km']
    let columnsToQuery = ['id', 'name', 'country', 'region', 'subregion', 'last_eruption', 'summit', 'elevation', 'latitude',
        'longitude']

    //decontruct parameters
    const { id, ...remaining } = req.params;

    //Test for invalid parameters
    if (Object.keys(remaining).length > 0) {
        res.status(400).json({ "error": true, "message": "Invalid query parameters. Only country and populatedWithin are permitted." });
        return;
    }

    //if authorised then add extra parameters to query
    if (res.locals.isAuthed) {
        columnsToQuery = [...columnsToQuery, ...authedCols]
    }

    //get desired data from database
    req.db.from('data').select(columnsToQuery).where('id', id)
        .then(rows => {
            if (rows.length === 0) {
                //if id is incorrect then error
                res.status(404).json({
                    "error": true,
                    "message": `Volcano with ID: ${id} not found.`
                })
                return;
            } else {
                //retrun status 200 if successful
                res.status(200).json(rows.shift());
                return;
            }
        })
        .catch(err => {
            console.log(err);
            //return error if error fetchong data in database
            res.status(200).json({ "error": true, "message": "Error in MySQL query" });
            return;
        })

});

module.exports = router;
