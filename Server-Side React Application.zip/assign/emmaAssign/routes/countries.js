var express = require('express');
var router = express.Router();

router.get('/', function (req, res, next) {

  const { country } = req.query;

  req.db.from('data').distinct('country').orderBy('country', 'asc')
    .then(rows => {
      res.json(
        rows.map(row => row.country)
      );
    })
    .catch(err => {
      console.log(err);
      res.json({ "error": true, "message": "Error in MySQL query" });
    }
    )
});

module.exports = router;
