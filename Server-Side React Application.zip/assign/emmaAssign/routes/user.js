var express = require('express');
var router = express.Router();

const authorize = require('../authorise');
const { DateTime } = require("luxon");

router.post('/register', function (req, res, next) {
  //recieve email and password from req.body
  const { email, password } = req.body;

  var bcrypt = require('bcryptjs');

  //if email or password is empty then error
  if (!email || !password) {
    res.status(400).json({
      "error": true,
      "message": "Request body incomplete, both email and password are required"
    });
    return;
  }

  //if user exists, return error
  const query = req.db.from('users').select('*').where('email', email)
  query
    .then(users => {
      if (users.length > 0) {
        res.status(409).json({
          "error": true,
          "message": "User already exists"
        });
        return;
      }
      //if user does not exist insert into table and hide password
      const saltRounds = 10
      const hash = bcrypt.hashSync(password, saltRounds)
      req.db.from("users").insert({ email, hash })
        .then(() => {
          res.status(201).json({
            "message": "User created"
          });
          return;
        })
    })
    .catch(err => {
      console.log(err);
      //error if failed to fetch data from database
      res.status(200).json({ "error": true, "message": "Error in MySQL query" });
      return;
    })
});

router.post('/login', function (req, res, next) {
  //recieve email and password from req.body
  const { email, password } = req.body;

  var bcrypt = require('bcryptjs');
  var jwt = require("jsonwebtoken");

  //error if email or password is empty
  if (!email || !password) {
    res.status(400).json({
      "error": true,
      "message": "Request body incomplete, both email and password are required"
    });
    return;
  }

  //check if user exists in database
  const query = req.db.from('users').select('*').where('email', email)
  query
    .then(users => {
      if (users.length === 0) {
        //error if they are not found in database
        res.status(401).json({
          "error": true,
          "message": "Incorrect email or password"
        });
        return;
      }
      //if user found then check password
      const user = users[0]
      bcrypt.compare(password, user.hash)
        .then((match) => {
          if (!match) {
            //return error if password and email did not match
            res.status(401).json({
              "error": true,
              "message": "Incorrect email or password"
            });
            return;
          }

          //create token for successful log in
          const expires_in = 60 * 60 * 24 //1 day
          const exp = Date.now() + expires_in * 1000
          const token = jwt.sign({ email, exp }, process.env.SECRET_KEY)

          res.status(200).json({
            "token": token,
            "token_type": "Bearer",
            "expires_in": expires_in
          });
          return;
        })
    })
    .catch(err => {
      //error if failed to fetch data from database
      console.log(err);
      res.status(200).json({ "error": true, "message": "Error in MySQL query" });
      return;
    })

});

router.put('/:email/profile', (req, res, next) => authorize(req, res, next, false), (req, res, next) => {

  //desired parameters depending if authorised or not
  const authedCols = ['dob', 'address']
  let columnsToQuery = ['email', 'firstName', 'lastName']

  //decontruct parms and body
  const { email } = req.params;
  const { firstName, lastName, dob, address } = req.body;

  //check if correct user
  if (res.locals.email !== email) {
    res.status(403).json({
      "error": true,
      "message": "Forbiden"
    })
    return;
  }

  //check if invalid profile format
  if (!address || !firstName || !lastName || !dob) {
    res.status(400).json({
      "error": true,
      "message": "Request body incomplete: firstName, lastName, dob and address are required."
    })
    return;
  }

  //check if parms are correct format
  if (typeof address !== 'string' || typeof lastName !== 'string' || typeof firstName !== 'string') {
    res.status(400).json({
      "error": true,
      "message": "Request body invalid: firstName, lastName and address must be strings only."
    })
    return;
  }

  //check if date is correct format
  if (!DateTime.fromFormat(dob, 'yyyy-MM-dd').isValid) {
    res.status(400).json({
      "error": true,
      "message": "Invalid input: dob must be a real date in format YYYY-MM-DD."
    })
    return;
  }

  //check if date is in future
  if (DateTime.fromISO(dob) > DateTime.now()) {
    res.status(400).json({
      "error": true,
      "message": "Invalid input: dob must be a date in the past."
    })
    return;
  }

  //update details in database
  req.db.from('users').update({ firstName, lastName, dob, address }).where('email', email)
    .then(rows => {
      res.status(200).json({ email, firstName, lastName, dob, address });
      return;
    })
    .catch(err => {
      console.log(err);
      //error if problem in mySQL
      res.status(200).json({ "error": true, "message": "Error in MySQL query" });
      return;
    }
    )
});

router.get('/:email/profile', (req, res, next) => authorize(req, res, next, true), (req, res, next) => {

  //desired parameters depending if authorised or not
  const authedCols = ['dob', 'address']
  let columnsToQuery = ['email', 'firstName', 'lastName']

  //deconstruct parms
  const { email } = req.params;

  //check if correct email, if so then add authorised cols
  if (res.locals.email === email) {
    columnsToQuery = [...columnsToQuery, ...authedCols]
  }

  //get data from databse for specifc email
  req.db.from('users').select(columnsToQuery).where('email', email)
    .then(rows => {
      if (rows.length === 0) {
        //if databse returns no one then error
        res.status(404).json({
          "error": true,
          "message": "User not found"
        })
        return;
      } else {
        res.status(200).json(rows.shift());
        return;
      }
    })
    .catch(err => {
      console.log(err);
      //error if problem fetching data
      res.status(200).json({ "error": true, "message": "Error in MySQL query" });
      return;
    }
    )

});

module.exports = router;