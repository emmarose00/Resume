//#include <stdio.h> //print f (delete)
//#include <stdlib.h> //delete
#include <unistd.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <fcntl.h>

//printf colour codes
#define RESET       "\033[0m"   //black
#define BHI_RED    "\e[1;91m"   //bold high intensity red
#define RED     "\033[31m"      //red

#include "shared_data.h"
#define SHARE_NAME "/xyzzy_123"

#define LIMIT 5
#define Smooth_LIMIT 30
#define MAX_PARKING_LEVELS 5

int firealarm = 0;

typedef struct level{
    int temperature_array_count;
    float Temperature_Array[LIMIT];
    int smooth_array_count;
    float Smooth_Array[Smooth_LIMIT];
}level_t;

int get_shared_object( shared_memory_t* PARKING, const char* share_name ) {
    PARKING->fd = shm_open(share_name, O_RDWR, sizeof(shared_data_t));
    if (PARKING->fd == -1){
        PARKING->data = NULL;
        return 0;
    }

    else if ((PARKING->data= mmap(0, sizeof(shared_data_t),PROT_WRITE|PROT_READ,MAP_SHARED,PARKING->fd,0)) == MAP_FAILED) return 0;
    if (PARKING->fd >=0 && PARKING->data != NULL) return 1;
}

int smooth_array_check(level_t *LEVEL,int level){
    int high_temperature = 0;
    
    for(int i=0; i<Smooth_LIMIT; i++){
        if (LEVEL[level].Smooth_Array[i]>=58){
            high_temperature++;
        }
    }

    if (high_temperature >= 30*0.9){
        firealarm = 1;
        return firealarm;
    }
    
}

void delete_smooth(level_t *LEVEL,int level){
    for (int i=0; i<Smooth_LIMIT; i++){    
       LEVEL[level].Smooth_Array[i] = LEVEL[level].Smooth_Array[i+1];
    }
    LEVEL[level].smooth_array_count--;
}

float temperature_array_average (level_t *LEVEL,int level){
    float average = 0;
    for(int i=0;i<LEVEL[level].temperature_array_count;i++){
        average+=LEVEL[level].Temperature_Array[i];
    }
    average = average/LEVEL[level].temperature_array_count;
    return average;
}

int insert_smooth_array(level_t *LEVEL, float average,int level){
    
    if((average-LEVEL[level].Smooth_Array[0]) >= 8.0 && LEVEL[level].smooth_array_count>0){
        firealarm = 1;
        //printf(BHI_RED"Temperature spike detected\n"RESET);
        return 1;
    }
    
    if(LEVEL[level].smooth_array_count == Smooth_LIMIT){
        
        if (smooth_array_check(LEVEL,level) == 1){
            firealarm = 1;
            //printf(BHI_RED"High temperatures detected\n"RESET);
            return 1;
        }
        delete_smooth(LEVEL,level);
    }
    
    LEVEL[level].Smooth_Array[LEVEL[level].smooth_array_count] = average;
    LEVEL[level].smooth_array_count++;
    return 0;
}

void delete_temperature (level_t *LEVEL,int level){

    for (int i=0; i<LIMIT; i++){    
       LEVEL[level].Temperature_Array[i] = LEVEL[level].Temperature_Array[i+1];
    }
    LEVEL[level].temperature_array_count--;

}

void insert_temperature (level_t *LEVEL,float temp_value,int level){   
    LEVEL[level].Temperature_Array[LEVEL[level].temperature_array_count] = temp_value;
    LEVEL[level].temperature_array_count++;
}

// void display_temperatures(level_t *LEVEL,int level){
    
//     printf("Temp_Array\nlevel %d -> ",level);
//     for(int i=0;i<LEVEL[level].temperature_array_count;i++){
//         printf("%.1f ",LEVEL[level].Temperature_Array[i]);
//     }
//     printf("\n");

//     if (LEVEL[level].temperature_array_count == 5){
//         printf("Smooth_Array\nlevel %d -> ",level);
//         for(int i=0;i<LEVEL[level].smooth_array_count;i++){
//             printf("%.1f ",LEVEL[level].Smooth_Array[i]);
//         }
//         printf("\n");
//     }
// }

int do_work( shared_memory_t* PARKING,level_t *LEVEL){
    sem_wait( &PARKING->data->firealarm_semaphore); 
    int retVal = 1;
    
    if(PARKING->data->update_temperature == 1){

        for(int level=0;level<MAX_PARKING_LEVELS;level++){
            if(LEVEL[level].temperature_array_count == LIMIT){
                float average = temperature_array_average(LEVEL, level);
                
                if (insert_smooth_array(LEVEL,average,level) == 1){
                    //printf(BHI_RED"\nFirealarm\n"RESET);
                    PARKING->data->firealarm = 1;
                    sem_post( &PARKING->data->manager_semaphore);
                    return 1;
                }
                delete_temperature(LEVEL,level);
                insert_temperature(LEVEL,PARKING->data->temperature_level[level],level);           
            }else{ 
                insert_temperature(LEVEL,PARKING->data->temperature_level[level],level);
            }

            usleep(50);
            //display_temperatures(LEVEL,level);
        }
        PARKING->data->update_temperature = 0;
    }

    
    sem_post( &PARKING->data->manager_semaphore);

    
    if (retVal == 0){
        munmap(PARKING,sizeof(shared_data_t));
        PARKING->fd = -1;
        PARKING->data = NULL;
    }
    return retVal; //return value

}

int main(void){
    //printf( "Firealarm starting.\n" );
    shared_memory_t PARKING;

    level_t LEVEL[MAX_PARKING_LEVELS];
    for(int level=0;level<MAX_PARKING_LEVELS;level++){
        LEVEL[level].smooth_array_count = 0;
        LEVEL[level].temperature_array_count = 0;
        for (int i = 0; i<LIMIT; i++){
            LEVEL[level].Temperature_Array[i] = 0;
        }

        for (int i = 0; i<Smooth_LIMIT; i++){
            LEVEL[level].Smooth_Array[i] = 0;
        }
    }

    if ( get_shared_object( &PARKING, SHARE_NAME ) ) {

        while (do_work(&PARKING,LEVEL)) {
            if(firealarm == 1) break;
        }  

        //printf( "Firealarm finished.\n" );
        
    }
    else {
        //printf( "Shared memory creation failed.\n" );
    }

}



