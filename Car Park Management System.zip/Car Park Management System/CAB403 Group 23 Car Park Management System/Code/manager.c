//**MANAGER**
//Instructions:
//gcc -o manager manager.c -lrt -pthread
//./manager
//run manager before simulator

#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>

#include "lists.h"
#include "shared_data.h"
#define SHARE_NAME "/xyzzy_123"

#define MAX_PARKING_LEVELS 5
#define MAX_VEHICLE_PER_LEVEL 20  //per level
#define MAX_REGO_LENGTH 8
#define REGO_PLATES_ALLOWED_FILENAME "plates.txt"
#define BOOMGATE_OPEN_DELAY 5000 //5 seconds
#define BOOMGATE_MAX_OPEN_TIME 20000
#define PARKING_COST_PER_MS 0.05 //5c per milisecond

//printf colour codes
#define BOLDMAGENTA "\033[1m\033[35m"   // Bold Magenta
#define BOLDRED     "\x1B[31m"          // Bold RED
#define BOLDCYAN    "\033[1m\033[36m"   // Bold Cyan
#define MAGENTA     "\033[35m"          // Magenta
#define CYAN        "\033[36m"          // Cyan
#define RESET       "\033[0m"

//GLOBAL VARIABLES
char ** permitted_rego_num;
int permitted_counted = 0;
float total_revenue = 0;
volatile void *PARKING_boomgate;

typedef struct main_sign_data{
    //data that will be displayed on main sign
    float temperature_level[MAX_PARKING_LEVELS];
    int current_capacity[MAX_PARKING_LEVELS];
    char boom_gate_status[MAX_PARKING_LEVELS];
    int entrance_LPR_status;
    int entrance_level_LPR_status[MAX_PARKING_LEVELS];
    int exit_level_LPR_status[MAX_PARKING_LEVELS];
    int alarm_status[MAX_PARKING_LEVELS];
    float total_revenue;
}main_sign_data_t;

//FUNCTIONS
void initalise_parking_levels (parking_levels_t *PARKING_LEVEL,main_sign_data_t *SIGN){
    //loads registration numbers from txt file (plates.txt) into an array (permitted_rego_num)
    //allows registration numbers up to maximum length (MAX_REGO_LENGTH)

    //initalise variable and allocate memory
    for (int level=1; level<=MAX_PARKING_LEVELS;level++){
        PARKING_LEVEL[level-1].current_capacity = 0;
        PARKING_LEVEL[level-1].parked_cars  = malloc(sizeof(char*));
        PARKING_LEVEL[level-1].entry_time = malloc(sizeof(time_t));

        SIGN->temperature_level[level-1] = 0;
        SIGN->current_capacity[level-1] = 0;
        SIGN->boom_gate_status[level-1] = 'C';
        SIGN->entrance_LPR_status = 0;
        SIGN->entrance_level_LPR_status[level-1] = 0;
        SIGN->exit_level_LPR_status[level-1] = 0;
        SIGN->alarm_status[level-1] = 0;
    }
    SIGN->total_revenue = 0;

    //allocating memory in dynamic array
    permitted_rego_num = malloc(sizeof(char*));                 //assigning a list of char*
    permitted_rego_num[0] = (char*)malloc(MAX_REGO_LENGTH+1);   //assigning space for rego string
    
    if (permitted_rego_num == NULL) {
        printf("Memory not allocated.\n");                    //memory allocation failed :(
        exit(0);
    }
    
    char buffer[MAX_REGO_LENGTH];
    FILE *fp = fopen(REGO_PLATES_ALLOWED_FILENAME, "r");    // file pointer = fp
    int c;                                                  //returns the int of the character
    int rego_n_pos = 0;
    


    if (fp==NULL){
        printf("Error Reading File.\n");
        return;
    }do{
        c = fgetc(fp);
        if(feof(fp)){
            break;
        }
        if (c == '\n'){                 //if c equals new line
            if(strlen(buffer)<=0){
                break;
            }else{
                //dynamic allocation of memory to load contents of the txt file
                permitted_counted++;
                
                //allocate memory for next rego_num
                permitted_rego_num = realloc(permitted_rego_num, permitted_counted*sizeof(char*));
                permitted_rego_num[permitted_counted-1] = (char*)malloc(MAX_REGO_LENGTH+1);
                                   
                if (permitted_rego_num == NULL) {
                    printf("Memory not allocated.\n");                    //memory allocation failed :(
                    exit(0);
                }

                strcpy(permitted_rego_num[permitted_counted-1], buffer);    //store num_plate witin data
                buffer[0] = 0;                                              //Reset buffer
                rego_n_pos = 0;                                             //move end pointer
                
            }
        }else{
            buffer[rego_n_pos] = c;
            buffer[rego_n_pos+1] = 0;
            rego_n_pos++;
            if (rego_n_pos>MAX_REGO_LENGTH){
                printf("Invalid Registration Number Found.\n"); //a number plate is longer than allowed
                return;
            }
        }
    }while(1);      
    fclose(fp);
    
}

bool create_shared_object( shared_memory_t* PARKING, const char* share_name ) {
    // Remove any previous instance of the shared memory object, if it exists.
    shm_unlink(share_name);

    // Assign share name to PARKING->name and initalise varibales
    PARKING->name = share_name;
    PARKING->data->rego_num[0] = '\0';
    PARKING->data->level = 0;
    PARKING->data->update_temperature = 0;
    
    // Create the shared memory object (read-write access)
    //If creation failed, PARKING->data is NULL and return false.
    if ((PARKING->fd=shm_open(share_name, O_RDWR|O_CREAT, 0666)) == -1){
        PARKING->data = NULL;
        return false;
    }
    
    // Set the capacity of the shared memory object via ftruncate. 
    //If the operation fails, PARKING->data is NULL and return false. 
    if (ftruncate(PARKING->fd,sizeof(shared_data_t))==-1){
        PARKING->data = NULL;
        return false;
    }else if ((PARKING->data= mmap(0, sizeof(shared_data_t),PROT_WRITE|PROT_READ,MAP_SHARED,PARKING->fd,0)) == MAP_FAILED) return false;

    //initalise semaphores
    sem_init( &PARKING->data->simulator_semaphore, 1, 0 );
    sem_init( &PARKING->data->manager_semaphore, 1, 0 );
    sem_init( &PARKING->data->firealarm_semaphore, 1, 0 );
    
    return true;
}

void destroy_shared_object( shared_memory_t* PARKING ) {
    // Remove the shared memory object.
    munmap(PARKING,sizeof(shared_data_t));
    shm_unlink(PARKING->name);
    PARKING->fd = -1;
    PARKING->data=NULL; 
}

int security_rego_check(char* rego_num, parking_levels_t *PARKING_LEVEL){  
    //reads licence plate and returns 1 if allowed and 0 if not
    for(int level = 1; level<=MAX_PARKING_LEVELS;level++){
        for (int i=0; i<PARKING_LEVEL[level-1].current_capacity; i++){
            if (strcmp(rego_num,PARKING_LEVEL[level-1].parked_cars[i])==0){     //compare with plates.txt (check each line)          
                printf("WARNING: Car already in car park.\n");
                return 0;                                                       //already in car park (not allowed to enter)
            } 
        }
    }

    //check if on permitted list
    for (int i=0; i<permitted_counted; i++){
        if (strcmp(rego_num,permitted_rego_num[i])==0){     //compare with plates.txt (check each line)          
            return 1;                                       //allowed to enter car park
        } 
    }
    return 0; //not on either permitted or in car park list (not allowed to enter)
}

int get_next_available_park_level(parking_levels_t *PARKING_LEVEL){
    int park_level = 1;
    int lowest_capacity = PARKING_LEVEL[0].current_capacity;

    //find level with lowest num of cars
    for(int level = 2; level<=MAX_PARKING_LEVELS;level++){
        if (PARKING_LEVEL[level-1].current_capacity < lowest_capacity){
            park_level = level;
            lowest_capacity = PARKING_LEVEL[level-1].current_capacity;
        }
    }

    if (lowest_capacity >= MAX_VEHICLE_PER_LEVEL){
        printf("Car Park Full.\n");
        return(-1);
    }else{
        return(park_level);
    } 
}

void entrance_sign_display(int level,char* rego_num){
    //entrance sign display message
    if (level == -1){
        printf(BOLDCYAN"Entrance\n"RESET); //displays entrance of detected car
        printf(CYAN"Car Not Allowed\n\n"RESET);
    }else{

        printf(BOLDCYAN"Entrance\n"RESET); //displays entrance of detected car
        printf(CYAN"Welcome %s,",rego_num);
        printf("proceed to level: %d\n\n"RESET, level);
    }
    
}

void *main_sign_display(void*arg){
    //pthread function of main sign
    while(1){
        main_sign_data_t *SIGNUPDATE = arg;

        system("clear");
        printf("\033c");
        printf(BOLDMAGENTA "Car Park Infomation\n");
        
        if (SIGNUPDATE->entrance_LPR_status==1)
            printf("\t Main Entrance LPR Status: %s\n","ON");
        else
            printf("\t Main Entrance LPR Status: %s\n","OFF");

        for(int i=0;i<MAX_PARKING_LEVELS;i++){ 
            printf(BOLDMAGENTA"Level %d:\n"RESET,i+1);
            printf(MAGENTA"\t Temperature: %.1f Dregrees Celsuis\n",SIGNUPDATE->temperature_level[i]);
            printf("\t Number of Cars: %d\n",SIGNUPDATE->current_capacity[i]);

            printf("\t Boom Gate Status: %c\n",SIGNUPDATE->boom_gate_status[i]);
            
            if (SIGNUPDATE->entrance_level_LPR_status[i]==1)
                printf("\t Entrance LPR Status: %s\n","ON");
            else
                printf("\t Entrance LPR Status: %s\n","OFF");
            
            if (SIGNUPDATE->exit_level_LPR_status[i]==1)
                printf("\t Exit LPR Status: %s\n","ON");
            else
                printf("\t Exit LPR Status: %s\n","OFF");
            
            if (SIGNUPDATE->alarm_status[i]==1)
                printf("\t Alarms: %s\n","ON");
            else
                printf("\t Alarms: %s\n","OFF");
        }

        printf(BOLDMAGENTA"Total Revenue: $%.2f\n\n"RESET, SIGNUPDATE->total_revenue);
        usleep(50000); //update every 50ms
        //sleep(1);
    }
    
}

void save_parked_cars(parking_levels_t *PARKING_LEVEL){
    //can be used by simulator or load cars incase of a program restart
    FILE *fp = fopen("parked_cars.txt", "w"); // file pointer = fp

    for (int l=1; l<=MAX_PARKING_LEVELS;l++){
        fprintf(fp, "[LEVEL %d]\n", l);
        for (int i=0; i<PARKING_LEVEL[l-1].current_capacity;i++){
            fprintf(fp,"%s\n",PARKING_LEVEL[l-1].parked_cars[i]);
        }
    }
    fclose(fp);
}

unsigned long get_time_ms(){
    //get current time
    struct timeval current_time;
    gettimeofday(&current_time, NULL);
    unsigned long time_ms = (current_time.tv_sec*1000000)+ current_time.tv_usec;
    return (time_ms);
}

void add_car_bill(char*rego_num,long parking_duration,float parking_cost){
    //billing file
    FILE *fp = fopen("billing.txt", "a"); // file pointer = fp a==append to file
    fprintf(fp,"%s %ldms $%.2f \n",rego_num, parking_duration, parking_cost);
    fclose(fp);
}

void add_car(parking_levels_t *PARKING_LEVEL,int level,char* rego_num){
    //adding car into array
    PARKING_LEVEL[level-1].current_capacity++;                
    PARKING_LEVEL[level-1].parked_cars[PARKING_LEVEL[level-1].current_capacity-1] = (char*)malloc(MAX_REGO_LENGTH+1);
    strcpy(PARKING_LEVEL[level-1].parked_cars[PARKING_LEVEL[level-1].current_capacity-1],rego_num);
    
    //add time to entry_time
    PARKING_LEVEL[level-1].entry_time = realloc(PARKING_LEVEL[level-1].entry_time,sizeof(unsigned long)*PARKING_LEVEL[level-1].current_capacity);
    PARKING_LEVEL[level-1].entry_time[PARKING_LEVEL[level-1].current_capacity-1] = get_time_ms();

    save_parked_cars(PARKING_LEVEL);
}

void remove_car(parking_levels_t *PARKING_LEVEL,int level, char*rego_num){

    int location;
    float parking_cost;

    for (int i=0; i<PARKING_LEVEL[level].current_capacity; i++){   
        if (strcmp(rego_num,PARKING_LEVEL[level-1].parked_cars[i])==0){           
            location = i;

            //calculating cost
            unsigned long begin = PARKING_LEVEL[level-1].entry_time[i];
            unsigned long end = get_time_ms();
            long parking_duration = (end - begin)/1000; //convert to ms
            parking_cost = parking_duration * PARKING_COST_PER_MS;
            add_car_bill(rego_num,parking_duration,parking_cost);
            break;
        } 
    }

    //adding to total revenue
    total_revenue += parking_cost;

    //removing from parked_cars and moving each rego_num up in array
    for (int i=location; i<PARKING_LEVEL[level-1].current_capacity-1; i++){    
        strcpy(PARKING_LEVEL[level-1].parked_cars[i],PARKING_LEVEL[level-1].parked_cars[i+1]);
    }

    //removing from entry_time 
    for (int i=location; i<PARKING_LEVEL[level-1].current_capacity-1; i++){    
        PARKING_LEVEL[level-1].entry_time[i] = PARKING_LEVEL[level-1].entry_time[i+1];
    }

    PARKING_LEVEL[level-1].current_capacity--;
    //reducing array sizes for parked_cars and entry_time for level
    if(PARKING_LEVEL[level-1].current_capacity>0){
        PARKING_LEVEL[level-1].parked_cars = realloc(PARKING_LEVEL[level-1].parked_cars,PARKING_LEVEL[level-1].current_capacity*sizeof(char*));
        PARKING_LEVEL[level-1].entry_time = realloc(PARKING_LEVEL[level-1].entry_time,sizeof(unsigned long)*PARKING_LEVEL[level-1].current_capacity);
    }else{
        PARKING_LEVEL[level-1].parked_cars  = malloc(sizeof(char*));
        PARKING_LEVEL[level-1].entry_time = malloc(sizeof(time_t));
    }
    save_parked_cars(PARKING_LEVEL);
}

void evacuate_sign(){
    char evacuate[9]={'E','V','A','C','U','A','T','E'};
    while(1){
        for(int i=0;i<9;i++){
            system("clear");
            printf(BOLDRED "%c ",evacuate[i]);
            usleep(2000); //2ms
        }
        printf("\n");
        usleep(1000000); //10ms
    }
    
}

void reset_shared_memory(shared_memory_t* PARKING){
    //reset memory
    PARKING->data->rego_num[0] = '\0';
    PARKING->data->LPR_exit = 0;
    PARKING->data->LPR_entrance = 0;
    PARKING->data->level = 0;
    PARKING->data->update_temperature = 0;
}

bool do_work( shared_memory_t* PARKING, parking_levels_t *PARKING_LEVEL, main_sign_data_t* SIGN,pthread_t mainsignID) {
    bool retVal = true;

    char rego_num[MAX_REGO_LENGTH];
    strcpy(rego_num,PARKING->data->rego_num);

    if (PARKING->data->level == -99){ //-99 = leave manager
        munmap(PARKING,sizeof(shared_data_t));
        PARKING->fd = -1;
        PARKING->data = NULL;
        return 0;
    }else if(PARKING->data->LPR_entrance == 1){ //entrance LPR activated
        if(PARKING->data->level == 0){ //entrance LPR secruity check
            //if rego_num in plates.txt (allowed to enter car par)
            SIGN->entrance_level_LPR_status[PARKING->data->level-1] = 1;
            if (security_rego_check(rego_num,PARKING_LEVEL) == 1){    
                
                int level = get_next_available_park_level(PARKING_LEVEL);
                SIGN->entrance_level_LPR_status[PARKING->data->level-1] = 0;
                PARKING->data->level = level;
                if (level<=0){ 
                    entrance_sign_display(-1,rego_num); //car park full                    
                }else{
                    // Open up boom gate
                    SIGN->boom_gate_status[level-1] = 'R';
                    usleep(10000); //10ms
                    SIGN->boom_gate_status[level-1] = 'O';

                }
            }
            sem_post( &PARKING->data->simulator_semaphore);
            sem_wait( &PARKING->data->manager_semaphore);

            //activate level entrance LPR
            if(PARKING->data->level > 0){
                //Car entering on level
                int level = PARKING->data->level;
                add_car(PARKING_LEVEL,level,rego_num); //add to array                 

                //signs updating
                entrance_sign_display(level,rego_num);
                
                //close boom gates
                usleep(10000); //10ms
                SIGN->boom_gate_status[level-1] = 'L';
                usleep(10000); //10ms
                SIGN->boom_gate_status[level-1] = 'C';
                
                SIGN->entrance_level_LPR_status[level-1] = 0;
            }

            sem_post( &PARKING->data->simulator_semaphore);
            sem_wait( &PARKING->data->manager_semaphore);
        }
    }else if(PARKING->data->LPR_exit == 1){ //exit LPR activated
        
        int level = PARKING->data->level;
        printf("Exit boomgate on level %d is opening\n",level);
        //opening boom gates
        SIGN->boom_gate_status[level-1] = 'R';
        usleep(10000);
        SIGN->boom_gate_status[level-1] = 'O';

        SIGN->exit_level_LPR_status[level-1] = 1;
                
        //remove car from array and calculate cost
        remove_car(PARKING_LEVEL,PARKING->data->level,rego_num);
        printf("Car (%s) is exiting\n",rego_num);
        
        //closing boom gates
        printf("Exit boomgate on level %d is closing\n",PARKING->data->level);
        usleep(10000);
        SIGN->boom_gate_status[level-1] = 'L';
        usleep(10000);
        SIGN->boom_gate_status[level-1] = 'C';

        sem_post( &PARKING->data->simulator_semaphore);
        sem_wait( &PARKING->data->manager_semaphore);

    }
    
    if(PARKING->data->update_temperature == 1){
        for(int level=1; level<=MAX_PARKING_LEVELS;level++){
            SIGN->temperature_level[level-1] = PARKING->data->temperature_level[level-1];
            sem_post( &PARKING->data->firealarm_semaphore);
            sem_wait( &PARKING->data->manager_semaphore);

            //firealarm test
            if(PARKING->data->firealarm == 1){
                printf("Opening all boomgates\n");
                printf("firealarm\n");
                for(int level=0;level<5;level++){
                    SIGN->alarm_status[level]=1;
                    SIGN->boom_gate_status[level]='R';
                    usleep(10000);
                    SIGN->boom_gate_status[level]='O';
                    SIGN->current_capacity[level] = 0;
                    SIGN->total_revenue = total_revenue;
                    usleep(200000);
                }
                pthread_cancel(mainsignID);
                evacuate_sign();
            }
            reset_shared_memory(PARKING);
        }
    }
    
    for(int level=1; level<=MAX_PARKING_LEVELS;level++){
        SIGN->current_capacity[level-1] = PARKING_LEVEL[level-1].current_capacity;
    }
    SIGN->total_revenue = total_revenue;

    sem_post( &PARKING->data->simulator_semaphore);
    sem_wait( &PARKING->data->manager_semaphore);
   
    if (retVal == false){
        munmap(PARKING,sizeof(shared_data_t));
        PARKING->fd = -1;
        PARKING->data = NULL;
    }
    return retVal; //return value
}

void main() {

    printf( "Manager starting.\n" );
    shared_memory_t PARKING;    
    
    if (create_shared_object( &PARKING, SHARE_NAME ) ) {
        
        //declarations
        parking_levels_t PARKING_LEVEL[MAX_PARKING_LEVELS];
        pthread_t mainsignID;
        main_sign_data_t SIGN;
        PARKING.data->firealarm = 0;

        pthread_create(&mainsignID,NULL,main_sign_display,&SIGN);

        //initalise functions
        initalise_parking_levels(PARKING_LEVEL,&SIGN);
        
        while ( do_work( &PARKING,PARKING_LEVEL,&SIGN,mainsignID) ) {

        }             

        destroy_shared_object( &PARKING );
        printf( "Manager finished.\n" );
    }else {
        printf( "Shared memory connection failed.\n" );
    }

    
}
