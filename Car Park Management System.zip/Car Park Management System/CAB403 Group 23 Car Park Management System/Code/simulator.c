//**SIMULATOR**
//Instructions:
//gcc -o simulator simulator.c -lrt -pthread
//./simulator
//run manager before simulator

#include <fcntl.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>

#include "shared_data.h"
#define SHARE_NAME "/xyzzy_123"

#define MAX_REGO_LENGTH 8
#define REGO_PLATES_RANDOM_FILENAME  "random_plates.txt"
#define MAX_PARKING_LEVELS 5

//printf colour codes
#define RED     "\033[31m"      //red
#define RESET       "\033[0m"   //black

//global variables
int random_plates_count = 0;
char ** random_rego_num;

typedef struct parked_cars{
    int total;                  //amount of cars parked in car park
    char** rego_num;            //list of cars parked in car park
    int* level;                 //level each car is parked on
    unsigned long* exit_time;   //random duration car required to parked for
}parked_cars_t;

void initalise_parked_cars(parked_cars_t *PARKED_CARS){
    //initalising varibales and allocating memory
    PARKED_CARS->total = 0;
    PARKED_CARS->rego_num = malloc(sizeof(char*));
    PARKED_CARS->level = malloc(sizeof(int));
    PARKED_CARS->exit_time = malloc(sizeof(unsigned long));
}

void initalise_random_cars(){
    //allocating memory in dynamic array
    random_rego_num = malloc(sizeof(char*));                //assigning a list of char*
    random_rego_num[0] = (char*)malloc(MAX_REGO_LENGTH+1);  //assigning space for rego string
    
    if (random_rego_num == NULL) {
        printf("Memory not allocated.\n"); //memory allocation failed :(
        exit(0);
    }
    
    char buffer[MAX_REGO_LENGTH];
    FILE *fp = fopen(REGO_PLATES_RANDOM_FILENAME, "r"); // file pointer = fp
    int c;                                              //returns the int of the character
    int rego_n_pos = 0;
    
    //reading random plates file and loading into array
    if (fp==NULL){
        printf("Error Reading File\n");
        return;
    }do{
        c = fgetc(fp);
        if(feof(fp)){
            break;
        }
        if (c == '\n'){                                 //if c equals new line
            if(strlen(buffer)<=0){
                break;
            }else{
                
                //dynamic allocation of memory to load contents of the txt file
                random_plates_count++;
                random_rego_num = realloc(random_rego_num, random_plates_count*sizeof(char*));
                random_rego_num[random_plates_count-1] = (char*)malloc(MAX_REGO_LENGTH+1);
                                                      
                if (random_rego_num == NULL) {
                    printf("Memory not allocated.\n");                  //memory allocation failed :(
                    exit(0);
                }

                strcpy(random_rego_num[random_plates_count-1], buffer); //store num_plate witin data
                buffer[0] = 0;                                          //Reset buffer
                rego_n_pos = 0;                                         //reset position within rego num
                
            }
        }else{
            buffer[rego_n_pos] = c;                                     //add character to buffer
            buffer[rego_n_pos+1] = 0;                                   //move end pointer
            rego_n_pos++;
            if (rego_n_pos>MAX_REGO_LENGTH){
                printf("Invalid Registration Number Found\n");          //the number plate is longer than allowed
                return;
            }
        }
    }while(1);         
    fclose(fp);
}

bool get_shared_object( shared_memory_t* PARKING, const char* share_name ) {
    //connecting to shared memory object
    PARKING->fd = shm_open(share_name, O_RDWR, sizeof(shared_data_t));
    if (PARKING->fd == -1){
        PARKING->data = NULL;       //failed to get shared_object
        return false;
    }
    else if ((PARKING->data= mmap(0, sizeof(shared_data_t),PROT_WRITE|PROT_READ,MAP_SHARED,PARKING->fd,0)) == MAP_FAILED) return false;
    
    if (PARKING->fd >=0 && PARKING->data != NULL) return true;
}

unsigned long get_time_ms(){
    //get current time
    struct timeval current_time;
    gettimeofday(&current_time, NULL);
    unsigned long time_ms = ((current_time.tv_sec*1000000)+ current_time.tv_usec)/1000;
    return (time_ms);
}

int check_parking_completed(parked_cars_t *PARKED_CARS){
    //checking each cars specified parking time
    unsigned long current_time = get_time_ms();
    for (int i = 0; i<PARKED_CARS->total;i++){          //if it has been in car park for time will leave car park
        if((PARKED_CARS->exit_time[i])<current_time){
            return (i);
        }
    }
    return(-1);
}

void remove_random_car(int location){
    float parking_cost;
    
    //removing from random_rego_num and moving each rego_num up in array
    for (int i=location; i<random_plates_count-1; i++){    
        strcpy(random_rego_num[i],random_rego_num[i+1]);
    }
    
    //reallocating memory
    random_plates_count--;
    if(random_plates_count>0){
        random_rego_num = realloc(random_rego_num, random_plates_count*sizeof(char*));
    }else
        random_rego_num = realloc(random_rego_num, sizeof(char*));
}

void remove_parked_car(parked_cars_t *PARKED_CARS, int location){
    //removing from random_rego_num and exit_time and moving each up in array
    for (int i=location; i<PARKED_CARS->total-1; i++){    
        strcpy(PARKED_CARS->rego_num[i],PARKED_CARS->rego_num[i+1]);
        PARKED_CARS->level[i] = PARKED_CARS->level[i+1];
        PARKED_CARS->exit_time[i] = PARKED_CARS->exit_time[i+1];
    }

    //reallocate memory
    PARKED_CARS->total--;
    if(PARKED_CARS->total>0){
        PARKED_CARS->rego_num = realloc(PARKED_CARS->rego_num, PARKED_CARS->total*sizeof(char*));
        PARKED_CARS->level = realloc(PARKED_CARS->level, PARKED_CARS->total*sizeof(int));
        PARKED_CARS->exit_time = realloc(PARKED_CARS->exit_time, PARKED_CARS->total*sizeof(unsigned long));
    
    }else{
        PARKED_CARS->rego_num = realloc(PARKED_CARS->rego_num, sizeof(char*));
        PARKED_CARS->level = realloc(PARKED_CARS->level, sizeof(int));
        PARKED_CARS->exit_time = realloc(PARKED_CARS->exit_time, sizeof(unsigned long));  
    
    }

}

void reset_shared_memory(shared_memory_t* PARKING){
    //reset variables
    PARKING->data->rego_num[0] = '\0';
    PARKING->data->LPR_exit = 0;
    PARKING->data->LPR_entrance = 0;
    PARKING->data->level = 0;
    PARKING->data->update_temperature = 0;
}

void car_exit(shared_memory_t* PARKING,int i, parked_cars_t *PARKED_CARS){
    usleep(10000);                                              //driving to exit (delay 10ms)
    PARKING->data->level = PARKED_CARS->level[i];               //level car exiting from
    strcpy(PARKING->data->rego_num, PARKED_CARS->rego_num[i]);  //store leaving rego in shared memory
    PARKING->data->LPR_exit = 1;                                //activate exit LPR

    //activate boomgate opening
    sem_post( &PARKING->data->manager_semaphore);
    sem_wait( &PARKING->data->simulator_semaphore); 

    printf("Car (%s) exiting from level:%d\n",PARKED_CARS->rego_num[i],PARKED_CARS->level[i]);
    remove_parked_car(PARKED_CARS,i);                           //car exiting from car park
    reset_shared_memory(PARKING);                               //reset the shared memory
}

void add_parked_cars(parked_cars_t *PARKED_CARS, char* rego_num, int level){
    //add the rego num in parked cars array
    PARKED_CARS->total++;

    //reallocate memory for each variable
    PARKED_CARS->rego_num = realloc(PARKED_CARS->rego_num, PARKED_CARS->total*(sizeof(char*)));
    PARKED_CARS->rego_num[PARKED_CARS->total-1] = (char*)malloc(MAX_REGO_LENGTH+1);
    PARKED_CARS->level = realloc(PARKED_CARS->level, PARKED_CARS->total*sizeof(int));
    PARKED_CARS->exit_time = realloc(PARKED_CARS->exit_time, PARKED_CARS->total*sizeof(unsigned long));

    strcpy(PARKED_CARS->rego_num[PARKED_CARS->total-1],rego_num);               //add rego num into shared memory
    PARKED_CARS->level[PARKED_CARS->total-1] = level;                           //store level into parked cars array

    //give each rego_num a duration to be parked in car park
    unsigned long exit_time = get_time_ms()+(rand() % (190 - 100 + 1)) + 100;   //100-10000ms
    PARKED_CARS->exit_time[PARKED_CARS->total-1] = exit_time;                   //get random duration between 20s and 3s
}

void car_entry(shared_memory_t* PARKING, parked_cars_t *PARKED_CARS){
    srand(time(0));
    int i = rand()%random_plates_count;                                         //choose random car to enter
    printf("Car registration (%s) randomly selected, ",random_rego_num[i]);
    
    PARKING->data->level = 0;
    strcpy(PARKING->data->rego_num, random_rego_num[i]);                        //store rego_num of entering car into shared memory
    PARKING->data->LPR_entrance = 1;                                            //entrance LPR activated
    
    //tell manager to boomgate
    sem_post( &PARKING->data->manager_semaphore);
    sem_wait( &PARKING->data->simulator_semaphore);

    if(PARKING->data->level > 0){
        printf("go to level:%d\n",PARKING->data->level);
        usleep(2000);                                                           //driving to boomgate
        PARKING->data->LPR_entrance = 1;                                        //level LPR activated
        //PARKING->data->level = #; can change level for car to park on

        //activating level LPR after entering park
        sem_post( &PARKING->data->manager_semaphore);
        add_parked_cars(PARKED_CARS,random_rego_num[i],PARKING->data->level);
        sem_wait( &PARKING->data->simulator_semaphore);
    }else
        printf("car was denied entry\n");
    
    remove_random_car(i);                                                       //remove car from array
    reset_shared_memory(PARKING);                                               //reset memory
}

void generate_random_temperature(shared_memory_t* PARKING){
    //generate normal temperatures for car park
    for(int i=0;i<MAX_PARKING_LEVELS; i++){
        PARKING->data->temperature_level[i] = rand() % (32 - 25 + 1) + 25;
    }
    PARKING->data->update_temperature = 1;
}

void generate_fire_temperature(shared_memory_t* PARKING){
    //generate normal temperatures on each level
    for(int i=0;i<MAX_PARKING_LEVELS; i++){
        PARKING->data->temperature_level[i] = rand() % (45 - 35 + 1) + 35;
    }

    //replace level 3 with higher temperatures to simulate a fire
    PARKING->data->temperature_level[3] = rand() % (70 - 55 + 1) + 55;
    PARKING->data->update_temperature = 1;
}

int check_fire_time(parked_cars_t *PARKED_CARS, unsigned long FIRE_TIME){
    //check if it is time for fire to start
    unsigned long current_time = get_time_ms();     //get current time
    if((FIRE_TIME)<current_time){       
            return (1);
    }
    return(0);
}

void main() {
    printf( RED"Simulator starting.\n" );
    
    //declaration of varibales
    shared_memory_t PARKING;
    

    if ( get_shared_object( &PARKING, SHARE_NAME ) ) {
        
        //initalise struct
        parked_cars_t *PARKED_CARS=malloc(sizeof(parked_cars_t)+sizeof(unsigned long));
    
        //initalising functions
        initalise_parked_cars(PARKED_CARS);
        initalise_random_cars();

        unsigned long FIRE_TIME = get_time_ms()+(rand() % (1000 - 900 + 1)) + 900;  //creating time that fire will begin in simulator

        while(1){
            
            sem_wait( &PARKING.data->simulator_semaphore);
        
            //cars entering
            if(random_plates_count>0){                  //amount in queue
                int random = rand()%10000;              //random num between 1-1000 (randomise entrance time)
                if(random<1){                           //0.1% chance of car entering
                    car_entry(&PARKING,PARKED_CARS);    //car approching entrance LPR
                }
            }

            //cars exiting
            if(PARKED_CARS->total>0){
                char* rego_num = NULL;
                int i = check_parking_completed(PARKED_CARS);   //check which cars who are due to leave car park
                if (i>=0){
                    car_exit(&PARKING,i,PARKED_CARS);           //exit cars that are due to leave
                    rego_num = NULL;
                }
            }

            //no more cars in entery queue
            if(random_plates_count == 0){
                printf("Random rego num is empty\n");
                random_plates_count = -1;
            }

            //generating temperatures for each level
           if (check_fire_time(PARKED_CARS,FIRE_TIME)){
                generate_fire_temperature(&PARKING);            //fire on level 3
            }else{
                generate_random_temperature(&PARKING);          //generating normal temperatures for each level
            }
            
            sem_post( &PARKING.data->manager_semaphore);
            reset_shared_memory(&PARKING);

        }
   
        printf( "Simulator finished.\n" );
        
    }
    else {
        printf( "Shared memory creation failed.\n" );
    }
}
