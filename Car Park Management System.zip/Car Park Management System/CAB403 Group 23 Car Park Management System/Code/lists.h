typedef struct parking_levels{
	
	size_t current_capacity; 		//current number of cars on level
	char ** parked_cars; 			//rego num of cars on level
	unsigned long* entry_time;		//time car entered into car park
	
}parking_levels_t;