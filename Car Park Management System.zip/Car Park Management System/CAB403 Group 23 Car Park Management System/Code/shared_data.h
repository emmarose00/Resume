#pragma once
#include <semaphore.h>

typedef struct shared_data {

    //synchronisation of processes
    sem_t simulator_semaphore;
    sem_t manager_semaphore;
    sem_t firealarm_semaphore;
    
    //entering and exiting
    int level;                  //level car required to park on
    char rego_num[8];           //number plate entering or exiting
    int LPR_entrance;           //entrance LPR (1=activated)
    int LPR_exit;               //exit LPR (1=activated)

    //firealarm data
    float temperature_level[5]; //current temperatures for each level
    int firealarm;              //firealarm (1=actiavted)
    int update_temperature;     //new current temperatures (update manager and firealarm old temperatures)
    
} shared_data_t;

typedef struct shared_memory {
    
    const char* name;           //shared memory object name
    int fd;                     //file descriptor used to manage shared memory object
    shared_data_t* data;        //address of the shared data block. 

} shared_memory_t;
